// server.js (Node.js + Express Backend)
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/health_tracker', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const WorkoutSchema = new mongoose.Schema({
  type: String,
  duration: Number,
  caloriesBurned: Number,
});

const HealthLogSchema = new mongoose.Schema({
  calories: Number,
  sleep: Number,
  workouts: [WorkoutSchema],
  date: { type: Date, default: Date.now },
});

const HealthLog = mongoose.model('HealthLog', HealthLogSchema);

// GET logs
app.get('/api/logs', async (req, res) => {
  const logs = await HealthLog.find().sort({ date: -1 }).limit(7);
  res.json(logs);
});

// POST log
app.post('/api/logs', async (req, res) => {
  const { calories, sleep, workout, duration, burned } = req.body;
  const newLog = new HealthLog({
    calories,
    sleep,
    workouts: [{ type: workout, duration, caloriesBurned: burned }],
  });
  await newLog.save();
  res.status(201).json({ message: 'Log saved' });
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
