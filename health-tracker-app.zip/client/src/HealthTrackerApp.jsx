// HealthTrackerApp.jsx (React Frontend)
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line, Bar, Pie } from 'react-chartjs-2';
import 'chart.js/auto';

export default function HealthTrackerApp() {
  const [logs, setLogs] = useState([]);
  const [form, setForm] = useState({ calories: '', sleep: '', workout: '', duration: '', burned: '' });

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    const res = await axios.get('http://localhost:5000/api/logs');
    setLogs(res.data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/logs', form);
    setForm({ calories: '', sleep: '', workout: '', duration: '', burned: '' });
    fetchLogs();
  };

  const data = {
    labels: logs.map(l => new Date(l.date).toLocaleDateString()),
    datasets: [
      {
        label: 'Calories Consumed',
        data: logs.map(l => l.calories),
        borderColor: 'blue',
        backgroundColor: 'rgba(0,0,255,0.3)',
      },
      {
        label: 'Calories Burned',
        data: logs.map(l => l.workouts.reduce((sum, w) => sum + w.caloriesBurned, 0)),
        borderColor: 'green',
        backgroundColor: 'rgba(0,255,0,0.3)',
      }
    ]
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Health Tracker App</h1>

      <form className="mb-6 grid gap-2" onSubmit={handleSubmit}>
        <input type="number" placeholder="Calories" value={form.calories} onChange={e => setForm({ ...form, calories: e.target.value })} />
        <input type="number" placeholder="Sleep (hrs)" value={form.sleep} onChange={e => setForm({ ...form, sleep: e.target.value })} />
        <input type="text" placeholder="Workout Type" value={form.workout} onChange={e => setForm({ ...form, workout: e.target.value })} />
        <input type="number" placeholder="Duration (min)" value={form.duration} onChange={e => setForm({ ...form, duration: e.target.value })} />
        <input type="number" placeholder="Calories Burned" value={form.burned} onChange={e => setForm({ ...form, burned: e.target.value })} />
        <button className="bg-blue-500 text-white px-4 py-2">Add Entry</button>
      </form>

      <Bar data={data} />
    </div>
  );
}
