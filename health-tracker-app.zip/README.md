# 🏥 Health Tracker App

Track your daily health stats like **calories consumed**, **sleep hours**, and **workouts**. This full-stack web app visualizes your health patterns with beautiful charts to help improve your well-being.

## ⚙️ Tech Stack

| Layer         | Technology        |
|---------------|-------------------|
| Frontend      | React.js, Chart.js|
| Backend       | Node.js, Express  |
| Database      | MongoDB           |

## 📦 Setup Instructions

### 📁 Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/health-tracker-app.git
cd health-tracker-app
```

### 📂 Backend Setup
```bash
cd server
npm install
node server.js
```

Ensure MongoDB is running on `mongodb://localhost:27017/health_tracker`

### 💻 Frontend Setup
```bash
cd ../client
npm install
npm start
```

## 🔑 Features

- ➕ Add entries for:
  - Calorie intake
  - Sleep (in hours)
  - Workouts (type, duration, calories burned)
- 📊 View logs in interactive charts (using Chart.js)
- 🧠 Data stored securely in MongoDB
- 🔁 Fetch and visualize the last 7 logs

## 🚀 Future Improvements
- User login/auth (JWT)
- Report downloads (PDF/CSV)
- Mobile responsive UI
- Notifications/reminders
